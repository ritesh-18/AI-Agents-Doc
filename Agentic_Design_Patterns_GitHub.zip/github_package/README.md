# Agentic Design Patterns — Easy Language Guide

> **Book:** *Agentic Design Patterns: A Hands-On Guide to Building Intelligent Systems* by Antonio Gulli  
> **Purpose:** A plain-English summary of all 21 patterns, with JavaScript code examples and book diagrams.  
> **GitHub Structure:** Keep this file as `README.md` and put all images in an `images/` folder beside it.

---

## Table of Contents

1. [What is an AI Agent?](#what-is-an-ai-agent)
2. [Why Design Patterns Matter](#why-design-patterns-matter)
3. [Part 1 — Core Patterns](#part-1--core-patterns)
   - [Ch 1: Prompt Chaining](#chapter-1-prompt-chaining)
   - [Ch 2: Routing](#chapter-2-routing)
   - [Ch 3: Parallelization](#chapter-3-parallelization)
   - [Ch 4: Reflection](#chapter-4-reflection)
   - [Ch 5: Tool Use (Function Calling)](#chapter-5-tool-use-function-calling)
   - [Ch 6: Planning](#chapter-6-planning)
   - [Ch 7: Multi-Agent Collaboration](#chapter-7-multi-agent-collaboration)
4. [Part 2 — Memory & Adaptation](#part-2--memory--adaptation)
   - [Ch 8: Memory Management](#chapter-8-memory-management)
   - [Ch 9: Learning and Adaptation](#chapter-9-learning-and-adaptation)
   - [Ch 10: Model Context Protocol (MCP)](#chapter-10-model-context-protocol-mcp)
   - [Ch 11: Goal Setting and Monitoring](#chapter-11-goal-setting-and-monitoring)
5. [Part 3 — Robustness & Safety](#part-3--robustness--safety)
   - [Ch 12: Exception Handling and Recovery](#chapter-12-exception-handling-and-recovery)
   - [Ch 13: Human-in-the-Loop](#chapter-13-human-in-the-loop)
   - [Ch 14: Knowledge Retrieval (RAG)](#chapter-14-knowledge-retrieval-rag)
6. [Part 4 — Advanced Patterns](#part-4--advanced-patterns)
   - [Ch 15: Inter-Agent Communication (A2A)](#chapter-15-inter-agent-communication-a2a)
   - [Ch 16: Resource-Aware Optimization](#chapter-16-resource-aware-optimization)
   - [Ch 17: Reasoning Techniques](#chapter-17-reasoning-techniques)
   - [Ch 18: Guardrails / Safety Patterns](#chapter-18-guardrailssafety-patterns)
   - [Ch 19: Evaluation and Monitoring](#chapter-19-evaluation-and-monitoring)
   - [Ch 20: Prioritization](#chapter-20-prioritization)
   - [Ch 21: Exploration and Discovery](#chapter-21-exploration-and-discovery)
7. [Quick Reference Cheat Sheet](#quick-reference-cheat-sheet)

---

## What is an AI Agent?

An **AI Agent** is like a smart assistant that doesn't just answer one question — it can take a goal, make a plan, use tools, and keep going until the job is done.

Think of it like this: if you ask a regular AI chatbot "organize my schedule," it gives you advice. An AI agent actually *does* it — it reads your emails, checks your calendar, sends invites, and reschedules conflicts.

### The 5-Step Agent Loop

![Agent Loop — the AI perceives, thinks, plans, acts and learns in a cycle](images/agent_loop.png)

Every agent follows a simple loop:

1. **Get the Mission** — You give it a goal (e.g., "organize my schedule")
2. **Scan the Scene** — It gathers info: reads emails, checks calendars
3. **Think It Through** — It plans the best approach
4. **Take Action** — Sends invites, updates calendar
5. **Learn and Improve** — If a meeting gets rescheduled, it learns and adapts

### Levels of Agent Complexity

![Agent Levels — from simple LLM to full multi-agent teams](images/agent_levels.png)

| Level | What It Can Do | Example |
|-------|---------------|---------|
| **Level 0** — Core Reasoner | Answers from training data only | Explaining history |
| **Level 1** — Connected Solver | Uses tools to get external data | Live stock price lookup |
| **Level 2** — Strategic Solver | Plans multi-step tasks, engineers context | Travel assistant booking a trip |
| **Level 3** — Multi-Agent System | Team of specialists collaborating | Product launch with research, design, and marketing agents |

### The Future of Agents

![Five hypotheses for where agents are heading](images/agent_future.png)

Five big predictions:

1. **Generalist Agents** — One agent that manages any complex goal for weeks
2. **Deep Personalization** — Agents that *know* you and proactively help
3. **Physical World Agents** — Robots that fix your leaky tap
4. **Agent Economy** — Agents running entire businesses autonomously
5. **Self-Designing Systems** — Agent teams that rewrite their own code to get better

---

## Why Design Patterns Matter

Building an agent is complex. Without proven patterns, developers waste time reinventing solutions to common problems. These **21 patterns** are like blueprints for the most common challenges in agent design.

> Just as an architect uses known patterns (arches, load-bearing walls) so they don't re-invent physics, agent developers use these patterns to build reliable intelligent systems faster.

---

## Part 1 — Core Patterns

---

### Chapter 1: Prompt Chaining

**The simple idea:** Instead of asking an AI to do everything in one giant request (which often fails), break the task into a *chain* of smaller steps — each output feeds the next input.

**Real-world analogy:** Writing a report — you research, then outline, then draft, then edit. Each step builds on the last.

![Prompt Chaining — output of each step becomes input for the next](images/prompt_chaining.png)

**Why single prompts fail on complex tasks:**
- The AI loses track of early instructions (context drift)
- Errors in one part cascade (error propagation)
- The AI hallucinates when overwhelmed

**The fix — chain it:**

| Step | Prompt | Output |
|------|--------|--------|
| 1 | "Summarize this document" | Clean summary |
| 2 | "Identify 3 trends from this summary" | JSON trends |
| 3 | "Write an email about these trends" | Final email |

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function promptChain(documentText) {
  // Step 1: Summarize
  const summaryRes = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: "You are a market analyst. Summarize concisely." },
      { role: "user", content: documentText }
    ]
  });
  const summary = summaryRes.choices[0].message.content;
  console.log("Step 1 - Summary done");

  // Step 2: Extract trends as structured JSON
  const trendsRes = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: `Extract top 3 trends as JSON array:
          [{"trend":"...","evidence":"..."}]
          Reply with ONLY the JSON, no other text.`
      },
      { role: "user", content: `Summary:\n${summary}` }
    ]
  });
  const trends = JSON.parse(trendsRes.choices[0].message.content);
  console.log("Step 2 - Trends extracted:", trends.length);

  // Step 3: Write email using the trends
  const emailRes = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: "Write a professional email to the marketing team about these trends."
      },
      { role: "user", content: JSON.stringify(trends, null, 2) }
    ]
  });

  const email = emailRes.choices[0].message.content;
  console.log("Step 3 - Email drafted:\n", email);
  return email;
}

promptChain("Q3 sales grew 12% driven by Gen Z consumers preferring eco-friendly products...");
```

**Key Takeaways:**
- Break tasks into focused sequential steps
- Each step's output becomes the next step's input
- Use **structured JSON** between steps to avoid ambiguity
- Use when a task has multiple distinct processing stages

---

### Chapter 2: Routing

**The simple idea:** Not all requests are the same. A smart agent looks at what you're asking and sends it to the *right specialist* — instead of trying to handle everything the same way.

**Real-world analogy:** When you call a company, the phone system routes you — press 1 for billing, press 2 for tech support. The AI does this automatically by understanding your message.

![Routing — LLM classifies intent and sends to correct handler](images/routing.png)

**Types of routers:**
- **LLM-based** — Ask the model: "Is this a booking or info request? One word."
- **Rule-based** — Simple if/else on keywords
- **Embedding-based** — Find semantically closest route using vector similarity

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const handlers = {
  booking: (req) => `✈️  Booking confirmed for: "${req}"`,
  info:    (req) => `ℹ️  Here is information about: "${req}"`,
  unclear: (req) => `❓ Could not understand: "${req}". Please clarify.`
};

async function classifyRequest(message) {
  const res = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: `Classify the user message into exactly one category:
          - "booking" (flights, hotels, appointments)
          - "info" (general knowledge questions)
          - "unclear" (anything else)
          Reply with ONLY one word.`
      },
      { role: "user", content: message }
    ]
  });
  return res.choices[0].message.content.trim().toLowerCase();
}

async function routeRequest(userMessage) {
  const intent = await classifyRequest(userMessage);
  console.log(`Intent detected: "${intent}"`);
  const handler = handlers[intent] || handlers.unclear;
  return handler(userMessage);
}

// Test
(async () => {
  console.log(await routeRequest("Book me a flight to London"));
  console.log(await routeRequest("What is the capital of Australia?"));
  console.log(await routeRequest("Do the thing with the stuff"));
})();
```

**Key Takeaways:**
- Routing makes agents dynamic and context-aware
- Use when different inputs need completely different workflows
- LLMs are excellent at intent classification with simple prompts
- Foundation for multi-purpose assistants and customer support bots

---

### Chapter 3: Parallelization

**The simple idea:** Instead of doing tasks one-by-one (A→B→C), run them *at the same time* (A+B+C simultaneously), then combine results.

**Real-world analogy:** When cooking, you don't boil pasta, *then* make the sauce, *then* prep the salad — you do them all at once.

![Parallelization — independent tasks run simultaneously, results merged](images/parallelization.png)

**When to parallelize:**
- Fetching data from multiple APIs
- Running different analyses on the same input
- Generating multiple content variations to compare

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function analyzeInParallel(topic) {
  console.log(`Analyzing "${topic}" with 3 parallel tasks...`);

  // Launch all 3 simultaneously with Promise.all
  const [summaryRes, questionsRes, keyTermsRes] = await Promise.all([
    client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "Summarize this topic in 2 sentences." },
        { role: "user", content: topic }
      ]
    }),
    client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "Generate 3 interesting questions about this topic." },
        { role: "user", content: topic }
      ]
    }),
    client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "List 5 key terms related to this topic, comma-separated." },
        { role: "user", content: topic }
      ]
    })
  ]);

  const summary   = summaryRes.choices[0].message.content;
  const questions = questionsRes.choices[0].message.content;
  const keyTerms  = keyTermsRes.choices[0].message.content;

  // Sequential synthesis step (waits for all parallel results)
  const finalRes = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: "Synthesize into a comprehensive overview." },
      {
        role: "user",
        content: `Summary: ${summary}\n\nQuestions: ${questions}\n\nKey Terms: ${keyTerms}\n\nTopic: ${topic}`
      }
    ]
  });

  console.log("Final Overview:\n", finalRes.choices[0].message.content);
}

analyzeInParallel("The impact of renewable energy on global economies");
```

**Key Takeaways:**
- `Promise.all()` is your parallel execution tool in JavaScript
- Only parallelize tasks that are **independent** of each other
- Final synthesis is still sequential (waits for all parallel results)
- Dramatically reduces total time for multi-step workflows

---

### Chapter 4: Reflection

**The simple idea:** After generating output, the agent looks back at its own work, critiques it, and improves it — like having an editor review your first draft.

**Real-world analogy:** A lawyer doesn't submit the first draft. They write, review against requirements, find weaknesses, revise, repeat.

![Reflection — generate, critique, refine in a feedback loop](images/reflection.png)

**Two models:**

| Model | How | Best For |
|-------|-----|----------|
| **Self-reflection** | Same AI reviews own output | Quick improvements |
| **Producer-Critic** | Different AI roles: one generates, one critiques | Higher objectivity |

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function reflectionLoop(task, maxIterations = 3) {
  let currentCode = "";

  for (let i = 0; i < maxIterations; i++) {
    console.log(`\n=== Iteration ${i + 1} ===`);

    // PRODUCER: Generate or refine
    const producerRes = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are an expert JavaScript developer. Write clean, well-commented code."
        },
        {
          role: "user",
          content: i === 0
            ? `Write a JavaScript function for: ${task}`
            : `Improve this JavaScript function based on the critique:\n\n${currentCode}`
        }
      ]
    });
    currentCode = producerRes.choices[0].message.content;
    console.log("Generated code (preview):", currentCode.substring(0, 120) + "...");

    // CRITIC: Review it
    const criticRes = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a senior code reviewer. Check:
            1. Functional correctness
            2. Edge case handling (null, empty, invalid types)
            3. Clear variable names and comments
            4. Efficiency
            
            If perfect → reply exactly "CODE_IS_PERFECT"
            Otherwise → bullet list of specific issues.`
        },
        {
          role: "user",
          content: `Task: ${task}\n\nCode:\n${currentCode}`
        }
      ]
    });

    const critique = criticRes.choices[0].message.content;
    if (critique.includes("CODE_IS_PERFECT")) {
      console.log(`\n✅ Approved after ${i + 1} iteration(s)!`);
      break;
    }
    console.log("Critique:", critique);
  }

  return currentCode;
}

reflectionLoop("calculate factorial of a number, handle 0 and negative input, include JSDoc");
```

**Key Takeaways:**
- Reflection creates a quality improvement loop
- Producer-Critic separation = more objective feedback
- Use when quality matters more than speed
- Best for: code generation, long-form content, detailed plans

---

### Chapter 5: Tool Use (Function Calling)

**The simple idea:** An AI's knowledge is frozen at training time. Tool use lets an agent "reach out" and call real functions — check live weather, query databases, send emails — giving it superpowers beyond training data.

**Real-world analogy:** A brilliant doctor with no internet can't tell you today's news. Tool use gives the doctor a phone so they can look things up and take real-world actions.

![Tool Use — the agent decides which tool to call, executes it, uses the result](images/tool_use.png)

**How it works step by step:**
1. Describe available tools to the LLM (name, description, parameters)
2. LLM decides *if* and *which* tool to call
3. LLM generates structured JSON: `{ "function": "get_weather", "args": { "location": "London" } }`
4. Your code runs the real function and returns the result
5. LLM uses the result to form its final answer

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Your actual tool functions
const toolFunctions = {
  get_weather: ({ location }) => {
    const data = {
      london: { temp: "15°C", condition: "Cloudy" },
      paris:  { temp: "20°C", condition: "Sunny"  },
      tokyo:  { temp: "28°C", condition: "Hot"    }
    };
    return data[location.toLowerCase()] ?? { error: "Location not found" };
  },
  get_stock_price: ({ ticker }) => {
    const prices = { AAPL: 178.50, GOOGL: 175.20, MSFT: 425.00 };
    const price = prices[ticker.toUpperCase()];
    return price ? { ticker, price, currency: "USD" } : { error: "Ticker not found" };
  }
};

// Describe tools for the LLM
const toolDefinitions = [
  {
    type: "function",
    function: {
      name: "get_weather",
      description: "Get current weather for a given city",
      parameters: {
        type: "object",
        properties: {
          location: { type: "string", description: "City name, e.g. London" }
        },
        required: ["location"]
      }
    }
  },
  {
    type: "function",
    function: {
      name: "get_stock_price",
      description: "Get current stock price for a ticker symbol",
      parameters: {
        type: "object",
        properties: {
          ticker: { type: "string", description: "Stock ticker, e.g. AAPL" }
        },
        required: ["ticker"]
      }
    }
  }
];

async function agentWithTools(userMessage) {
  const messages = [{ role: "user", content: userMessage }];

  // First call: AI decides what tools to use
  let response = await client.chat.completions.create({
    model: "gpt-4o",
    messages,
    tools: toolDefinitions,
    tool_choice: "auto"
  });

  let msg = response.choices[0].message;

  // If tools were called, execute them
  if (msg.tool_calls) {
    messages.push(msg); // Add AI's tool request to history

    for (const call of msg.tool_calls) {
      const fnName = call.function.name;
      const fnArgs = JSON.parse(call.function.arguments);
      console.log(`Calling tool: ${fnName}`, fnArgs);

      const result = toolFunctions[fnName](fnArgs);

      messages.push({
        role: "tool",
        tool_call_id: call.id,
        content: JSON.stringify(result)
      });
    }

    // Final call: AI uses tool results to answer
    response = await client.chat.completions.create({ model: "gpt-4o", messages });
    msg = response.choices[0].message;
  }

  console.log("Answer:", msg.content);
}

agentWithTools("What's the weather in London and the price of Apple stock?");
```

**Key Takeaways:**
- Tools break the LLM out of its static training-data bubble
- The LLM decides *when* to call a tool — you don't hardcode it
- Common tools: search, databases, email, weather APIs, calculators, code runners
- This is a foundational pattern — almost every real agent uses tool calling

---

### Chapter 6: Planning

**The simple idea:** For complex goals, don't just start doing things. First make a *plan* — break the big goal into ordered steps, then execute them one by one.

**Real-world analogy:** A project manager doesn't start a project randomly — they write a plan with phases, dependencies, and milestones first.

![Planning — decompose goal into steps, execute in order, adapt when needed](images/planning.png)

**What makes planning powerful:**
- The agent *discovers* the how, not just executes the what
- Plans adapt when obstacles arise (a venue unavailable → find another)
- Turns a single request into a coordinated sequence of actions

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function planningAgent(goal) {
  console.log(`\n🎯 Goal: ${goal}\n`);

  // Step 1: Generate plan
  const planRes = await client.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "system",
        content: `You are a planning agent. Given a goal, create an actionable numbered plan.
          Format as JSON: {"steps":[{"step":1,"action":"...","tool":"...","notes":"..."}]}`
      },
      { role: "user", content: `Create an action plan for: ${goal}` }
    ]
  });

  const plan = JSON.parse(planRes.choices[0].message.content);
  console.log("Plan:");
  plan.steps.forEach(s => console.log(`  ${s.step}. [${s.tool}] ${s.action}`));

  // Step 2: Execute each step
  const results = [];
  for (const step of plan.steps) {
    console.log(`\nExecuting step ${step.step}...`);

    const execRes = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "Execute this step and describe what was done and the result." },
        {
          role: "user",
          content: `Goal: ${goal}\nStep: ${step.action}\nNotes: ${step.notes}`
        }
      ]
    });

    results.push({ step: step.step, result: execRes.choices[0].message.content });
    console.log(`  ✅ Done`);
  }

  // Step 3: Final summary
  const summaryRes = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: "Summarize what was accomplished in a concise report." },
      { role: "user", content: `Goal: ${goal}\nResults: ${JSON.stringify(results)}` }
    ]
  });

  console.log("\n=== Summary ===\n", summaryRes.choices[0].message.content);
}

planningAgent("Research the top 3 trends in AI agents and write a brief report");
```

**Key Takeaways:**
- Planning converts a high-level goal into executable steps
- Plans should be *adaptive* — revise when something fails
- Use for multi-step, complex tasks where order matters
- Google Deep Research uses this: search → analyze → refine → synthesize → report

---

### Chapter 7: Multi-Agent Collaboration

**The simple idea:** Instead of one all-powerful agent doing everything, build a *team* of specialized agents — like a company where different departments handle different things.

**Real-world analogy:** A film production has a director, actors, cinematographers, editors, sound engineers — each expert does their part; together they create something none could do alone.

![Multi-Agent — specialist agents collaborate, coordinate, and combine outputs](images/multi_agent.png)

**Collaboration patterns:**

| Pattern | How It Works | Best For |
|---------|-------------|----------|
| **Sequential Handoff** | Agent A finishes → passes to Agent B | Pipelines with clear stages |
| **Parallel** | Multiple agents work simultaneously | Independent sub-tasks |
| **Hierarchical** | Manager agent delegates to workers | Complex workflows |
| **Debate & Consensus** | Agents argue different positions | Decision-making, fact-checking |
| **Critic-Reviewer** | One creates, another audits | High-quality content, code |

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function researcherAgent(topic) {
  console.log("[RESEARCHER] Researching:", topic);
  const res = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: "You are a Senior Research Analyst. Find the top 3 trends with key data points." },
      { role: "user", content: topic }
    ]
  });
  return res.choices[0].message.content;
}

async function writerAgent(research, audience) {
  console.log("[WRITER] Drafting blog post...");
  const res = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: `You are a Technical Content Writer. Write an engaging 400-word blog post for: ${audience}.
          Use simple language. Base it entirely on the research provided.`
      },
      { role: "user", content: `Research:\n${research}` }
    ]
  });
  return res.choices[0].message.content;
}

async function editorAgent(draft) {
  console.log("[EDITOR] Reviewing and polishing...");
  const res = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: `You are a Chief Editor. Review and improve the draft:
          1. Fix grammar and clarity
          2. Improve flow and engagement
          3. Add a compelling headline if missing
          Return ONLY the improved version.`
      },
      { role: "user", content: draft }
    ]
  });
  return res.choices[0].message.content;
}

// Orchestrate the team (sequential handoffs)
async function contentTeam(topic, audience) {
  console.log("\n🚀 Multi-agent content team starting...\n");
  const research  = await researcherAgent(topic);
  const draft     = await writerAgent(research, audience);
  const finalPost = await editorAgent(draft);
  console.log("\n=== FINAL POST ===\n", finalPost);
  return finalPost;
}

contentTeam(
  "The impact of AI agents on software development in 2025",
  "developers with 2-3 years of experience"
);
```

**Key Takeaways:**
- Specialized agents outperform generalist agents on complex tasks
- Communication between agents needs clear formats (JSON, structured text)
- Hierarchical patterns (manager + workers) scale to complex workflows
- Multi-agent is the foundation for systems like AutoGPT and Google DeepResearch

---

## Part 2 — Memory & Adaptation

---

### Chapter 8: Memory Management

**The simple idea:** Without memory, every conversation starts from zero. Memory lets agents remember you across sessions, track ongoing tasks, and learn from past interactions.

**Two types of memory:**

| Type | What It Is | Where It Lives | Example |
|------|-----------|---------------|---------|
| **Short-term** | Current conversation context | In the LLM context window | Messages sent so far |
| **Long-term** | Persists across conversations | External database / vector store | User preferences, past summaries |

![Memory — short-term context window plus long-term external vector store](images/memory.png)

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class AgentWithMemory {
  constructor() {
    this.conversationHistory = []; // Short-term: current session
    this.longTermMemory = {};       // Long-term: persists across sessions
  }

  save(key, value) {
    this.longTermMemory[key] = value;
    console.log(`[MEMORY] Saved: ${key} = "${value}"`);
  }

  getLongTermContext() {
    const entries = Object.entries(this.longTermMemory);
    if (!entries.length) return "";
    return "\n\nUser context from past sessions:\n" +
      entries.map(([k, v]) => `- ${k}: ${v}`).join("\n");
  }

  async chat(userMessage) {
    this.conversationHistory.push({ role: "user", content: userMessage });

    const systemMessage = {
      role: "system",
      content: "You are a helpful personal assistant. Use the user context provided." +
               this.getLongTermContext()
    };

    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [systemMessage, ...this.conversationHistory]
    });

    const reply = res.choices[0].message.content;
    this.conversationHistory.push({ role: "assistant", content: reply });

    // Auto-extract facts to long-term memory
    const nameMatch = userMessage.match(/my name is (\w+)/i);
    if (nameMatch) this.save("user_name", nameMatch[1]);
    if (/i prefer|i like/i.test(userMessage)) this.save(`pref_${Date.now()}`, userMessage);

    return reply;
  }

  // Compress history to save tokens
  async compressHistory() {
    if (this.conversationHistory.length < 8) return;

    const summaryRes = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "Summarize this conversation in bullet points, preserving key facts." },
        {
          role: "user",
          content: this.conversationHistory.map(m => `${m.role}: ${m.content}`).join("\n")
        }
      ]
    });

    this.save("conversation_summary", summaryRes.choices[0].message.content);
    this.conversationHistory = []; // Clear short-term
    console.log("[MEMORY] History compressed.");
  }
}

// Test
(async () => {
  const agent = new AgentWithMemory();
  console.log(await agent.chat("Hi! My name is Alex and I prefer concise answers."));
  console.log(await agent.chat("What's the weather like today?"));
  console.log(await agent.chat("Do you remember my name?")); // Agent should remember!
})();
```

**Key Takeaways:**
- Short-term memory = current chat; long-term = database/vector store
- Compress old conversations to save token costs
- Use vector databases (Pinecone, Weaviate, Chroma) for semantic memory search
- Without memory, agents can't maintain relationships or multi-session work

---

### Chapter 9: Learning and Adaptation

**The simple idea:** An agent that can't learn will always make the same mistakes. Learning agents improve over time — they update their knowledge, refine strategies, and adapt automatically.

**Remarkable real example — SICA (Self-Improving Coding Agent):** An agent that *rewrites its own code* to become better at programming tasks. It reviews past performance, identifies weaknesses, writes new tools, tests itself, and keeps the better version. In experiments it independently created smarter code editors and search tools — all by itself.

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class AdaptiveLearningAgent {
  constructor() {
    this.episodicMemory   = []; // Past interactions + outcomes
    this.successPatterns  = {};
    this.failurePatterns  = {};
  }

  recordExperience(input, wasSuccessful, feedback) {
    this.episodicMemory.push({ input, wasSuccessful, feedback });
    const key = input.substring(0, 50);
    if (wasSuccessful) this.successPatterns[key] = (this.successPatterns[key] || 0) + 1;
    else               this.failurePatterns[key] = (this.failurePatterns[key] || 0) + 1;
  }

  getInsights() {
    const top = obj => Object.entries(obj)
      .sort(([, a], [, b]) => b - a).slice(0, 2)
      .map(([k, v]) => `"${k}" (×${v})`).join(", ");
    return {
      successes: top(this.successPatterns) || "none yet",
      failures:  top(this.failurePatterns) || "none yet"
    };
  }

  async respond(message) {
    const { successes, failures } = this.getInsights();

    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are an adaptive assistant.
            Approaches that worked well: ${successes}
            Approaches to avoid: ${failures}
            Apply these lessons.`
        },
        { role: "user", content: message }
      ]
    });
    return res.choices[0].message.content;
  }

  // Self-improvement: refine own system prompt based on feedback
  async refineOwnInstructions(currentInstructions, recentFeedback) {
    const res = await client.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You improve AI system prompts based on user feedback." },
        {
          role: "user",
          content: `Current instructions:\n${currentInstructions}\n\nFeedback:\n${recentFeedback}\n\nImproved instructions:`
        }
      ]
    });
    return res.choices[0].message.content;
  }
}

(async () => {
  const agent = new AdaptiveLearningAgent();

  // Simulate recorded past experience
  agent.recordExperience("explain technical concept", false, "too complex, lost the user");
  agent.recordExperience("explain technical concept", true,  "simple analogy worked great!");
  agent.recordExperience("write code", true, "clean, well-commented code");

  const reply = await agent.respond("Explain what an API is");
  console.log("Response with learning:\n", reply);

  const improved = await agent.refineOwnInstructions(
    "You are a helpful assistant.",
    "Users say responses are too technical. They want simpler, shorter answers with analogies."
  );
  console.log("\nImproved instructions:\n", improved);
})();
```

**Key Takeaways:**
- Record what worked and what didn't after every interaction
- Episodic memory helps avoid repeating mistakes
- Self-improvement (modifying own prompts or code) is the frontier
- AlphaEvolve (Google) uses evolutionary learning to discover new mathematical algorithms

---

### Chapter 10: Model Context Protocol (MCP)

**The simple idea:** MCP is like a **universal USB standard for AI agents**. Instead of custom connections between each AI and each tool, MCP creates one standard so any AI can connect to any tool.

**Real-world analogy:** Before USB, every device had its own connector. USB standardized everything. MCP does the same for AI tools.

![MCP — standardized client-server interface between AI and external tools](images/mcp.png)

**MCP vs. Regular Tool Calling:**

| Feature | Tool Function Calling | MCP |
|---------|----------------------|-----|
| Standard | Varies by provider | Open standard (Anthropic) |
| Discovery | Static — you hardcode the tools | Dynamic — AI discovers at runtime |
| Reusability | Tightly coupled to one app | Reusable across many AIs |
| Architecture | One-to-one | Client-server |

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Simulated MCP Server — exposes tools any AI can discover and call
const mcpServer = {
  tools: [
    {
      name: "greet",
      description: "Generates a personalized greeting for a person",
      parameters: {
        type: "object",
        properties: { name: { type: "string", description: "Person's name" } },
        required: ["name"]
      }
    },
    {
      name: "calculate",
      description: "Evaluates a mathematical expression and returns the result",
      parameters: {
        type: "object",
        properties: { expression: { type: "string", description: "e.g. '12 * 7 + 3'" } },
        required: ["expression"]
      }
    }
  ],
  execute(toolName, args) {
    if (toolName === "greet") return { result: `Hello, ${args.name}! Nice to meet you.` };
    if (toolName === "calculate") {
      try {
        // eslint-disable-next-line no-new-func
        return { result: Function(`"use strict"; return (${args.expression})`)() };
      } catch { return { error: "Invalid expression" }; }
    }
    return { error: `Unknown tool: ${toolName}` };
  }
};

// MCP Client — how an agent discovers and uses the server's tools
class MCPClient {
  constructor(server) { this.server = server; }

  discoverTools() {
    console.log("Discovered tools:", this.server.tools.map(t => t.name));
    return this.server.tools;
  }

  callTool(name, args) {
    console.log(`Calling MCP tool: ${name}`, args);
    return this.server.execute(name, args);
  }
}

async function agentWithMCP(userMessage) {
  const mcp  = new MCPClient(mcpServer);
  const tools = mcp.discoverTools();

  // Translate MCP tool format → OpenAI tool format
  const openAITools = tools.map(t => ({ type: "function", function: t }));

  const res = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: userMessage }],
    tools: openAITools,
    tool_choice: "auto"
  });

  const msg = res.choices[0].message;
  if (msg.tool_calls) {
    for (const call of msg.tool_calls) {
      const result = mcp.callTool(call.function.name, JSON.parse(call.function.arguments));
      console.log("Tool result:", result);
    }
  }
}

agentWithMCP("Greet my colleague Sarah and calculate 15 multiplied by 7");
```

**Key Takeaways:**
- MCP standardizes AI-to-tool communication across providers
- Agents can *dynamically discover* tools without code changes
- Supported by Anthropic, and used in Claude, Cursor, and many others
- For simple projects use direct tool calling; for enterprise scale use MCP

---

### Chapter 11: Goal Setting and Monitoring

**The simple idea:** Agents need clear goals and a way to check whether they're making progress. Without monitoring, an agent might wander or never know if it succeeded.

**SMART Goals for AI:** Specific, Measurable, Achievable, Relevant, Time-bound.

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class GoalDrivenAgent {
  constructor(goal, successCriteria, maxIterations = 4) {
    this.goal = goal;
    this.criteria = successCriteria;
    this.maxIter = maxIterations;
    this.output = null;
  }

  async produce(previousOutput, feedback) {
    const prompt = previousOutput
      ? `Improve based on feedback:\nPrevious output:\n${previousOutput}\nFeedback:\n${feedback}`
      : `Produce output for: ${this.goal}`;

    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are a focused assistant. Produce exactly what is asked." },
        { role: "user", content: prompt }
      ]
    });
    return res.choices[0].message.content;
  }

  async checkGoal(output) {
    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a goal evaluator. Check if the output meets ALL criteria:
            ${this.criteria.map((c, i) => `${i + 1}. ${c}`).join("\n")}
            
            Reply ONLY "GOAL_ACHIEVED" or a bullet list of what is missing.`
        },
        { role: "user", content: `Goal: ${this.goal}\n\nOutput:\n${output}` }
      ]
    });
    return res.choices[0].message.content;
  }

  async run() {
    console.log(`\n🎯 Goal: ${this.goal}`);
    let feedback = null;

    for (let i = 0; i < this.maxIter; i++) {
      console.log(`\n--- Iteration ${i + 1} ---`);
      this.output = await this.produce(this.output, feedback);
      const evaluation = await this.checkGoal(this.output);

      if (evaluation.includes("GOAL_ACHIEVED")) {
        console.log(`✅ Goal achieved in ${i + 1} iteration(s)!`);
        return this.output;
      }
      feedback = evaluation;
      console.log("Feedback:", feedback.substring(0, 100));
    }

    console.log("⚠️ Max iterations reached.");
    return this.output;
  }
}

const agent = new GoalDrivenAgent(
  "Write a JavaScript function that reverses a string",
  [
    "Handles empty string input",
    "Handles null input without throwing",
    "Includes JSDoc comments",
    "Shows one usage example in comments"
  ]
);

agent.run().then(output => console.log("\n=== FINAL OUTPUT ===\n", output));
```

**Key Takeaways:**
- Define measurable goals *before* the agent starts
- Monitor progress continuously, not just at the end
- Feedback loops enable automatic course-correction
- Goal Monitoring + Reflection = a self-improving system

---

## Part 3 — Robustness & Safety

---

### Chapter 12: Exception Handling and Recovery

**The simple idea:** Things go wrong — APIs fail, tools crash, data gets corrupted. A resilient agent doesn't crash — it detects the problem, retries, falls back to alternatives, and degrades gracefully.

![Exception Handling — detect error, retry, fallback, degrade, escalate](images/exception_handling.png)

**Key strategies:**

| Strategy | When To Use |
|----------|------------|
| **Retry with backoff** | Transient errors (network hiccup) |
| **Fallback tool** | Primary service unavailable |
| **Graceful degradation** | Give partial result rather than crash |
| **Escalation** | Human intervention needed |

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Retry helper with exponential backoff
async function withRetry(fn, maxRetries = 3, baseDelay = 500) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      if (attempt === maxRetries) throw err;
      const delay = baseDelay * Math.pow(2, attempt - 1);
      console.log(`[RETRY] Attempt ${attempt} failed. Retrying in ${delay}ms...`);
      await new Promise(r => setTimeout(r, delay));
    }
  }
}

// Simulated primary tool (fails 50% of the time)
async function getPreciseLocation(address) {
  if (Math.random() < 0.5) throw new Error("Location API unavailable");
  return { address, lat: 51.5074, lng: -0.1278, precision: "exact" };
}

// Fallback tool (always works, less precise)
async function getApproximateLocation(city) {
  return { city, precision: "approximate", note: "Exact coordinates unavailable" };
}

class ResilientAgent {
  constructor() { this.errors = []; }

  logError(step, err) {
    this.errors.push({ step, message: err.message });
    console.error(`[ERROR] ${step}: ${err.message}`);
  }

  async locateWithFallback(address) {
    try {
      // Try primary with retries
      return await withRetry(() => getPreciseLocation(address));
    } catch (primaryErr) {
      this.logError("precise_location", primaryErr);
      console.log("[FALLBACK] Switching to approximate location...");
      try {
        const city = address.split(",")[0];
        return await getApproximateLocation(city);
      } catch (fallbackErr) {
        this.logError("approximate_location", fallbackErr);
        return { error: "All location services failed", status: "degraded" };
      }
    }
  }

  async respond(query) {
    const locationData = await this.locateWithFallback(query);

    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "Answer the location query. If data is degraded, acknowledge this honestly."
        },
        {
          role: "user",
          content: `Query: ${query}\nLocation data: ${JSON.stringify(locationData)}`
        }
      ]
    });
    return res.choices[0].message.content;
  }
}

(async () => {
  const agent = new ResilientAgent();
  const answer = await agent.respond("London, UK");
  console.log("Answer:", answer);
  console.log("Errors encountered:", agent.errors.length);
})();
```

**Key Takeaways:**
- Always retry transient errors with exponential backoff
- Have fallback tools/models ready when primary ones fail
- Log all errors — essential for debugging production agents
- Graceful degradation: partial success beats total failure

---

### Chapter 13: Human-in-the-Loop

**The simple idea:** Some decisions are too important, too ambiguous, or too risky for AI to make alone. HITL keeps humans involved at critical checkpoints.

![Human-in-the-Loop — AI handles routine, humans approve critical decisions](images/human_loop.png)

**When to use HITL:**
- High-stakes decisions (financial, medical, legal)
- Ambiguous edge cases
- Content moderation judgment calls
- Compliance requirements

**HITL vs Human-on-the-Loop:**
- **HITL** — Human approves each critical action before it runs
- **HOtL** — Human sets policy; AI acts automatically; human monitors dashboards

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class HumanInLoopAgent {
  constructor() { this.actionLog = []; }

  // Simulate human approval (in production: Slack message, web UI, email)
  async requestHumanApproval(action, details) {
    console.log(`\n⚠️  HUMAN APPROVAL REQUIRED`);
    console.log(`   Action: ${action}`);
    console.log(`   Details: ${JSON.stringify(details)}`);
    // In real systems: send to Slack/email and wait for webhook callback
    // For demo we simulate a human approving
    const approved = true; // Replace with actual human approval flow
    console.log(`   Decision: ${approved ? "✅ APPROVED" : "❌ REJECTED"}`);
    return approved;
  }

  async performAction(type, params, requiresApproval = false) {
    if (requiresApproval) {
      const approved = await this.requestHumanApproval(type, params);
      if (!approved) {
        return { success: false, reason: "Human rejected the action" };
      }
    }
    this.actionLog.push({ type, params, timestamp: new Date().toISOString() });
    return { success: true, action: type };
  }

  async handleRequest(userRequest) {
    // Step 1: Classify risk level
    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `Classify the request risk level:
            - "safe": informational, no action
            - "low_risk": simple automated action OK
            - "high_risk": needs human approval before acting
            - "escalate": too complex, hand off to human
            Reply ONLY as JSON: {"level":"...","reason":"..."}`
        },
        { role: "user", content: userRequest }
      ]
    });

    const { level, reason } = JSON.parse(res.choices[0].message.content);
    console.log(`\nRisk level: ${level} — ${reason}`);

    switch (level) {
      case "safe":
        const safeRes = await client.chat.completions.create({
          model: "gpt-4o-mini",
          messages: [{ role: "user", content: userRequest }]
        });
        return safeRes.choices[0].message.content;

      case "low_risk":
        await this.performAction("automated_action", { request: userRequest }, false);
        return "Action completed automatically.";

      case "high_risk":
        const result = await this.performAction("high_risk_action", { request: userRequest }, true);
        return result.success ? "Action completed after human approval." : `Blocked: ${result.reason}`;

      case "escalate":
        return "This request has been escalated to the human support team. Ticket #12345 created.";
    }
  }
}

(async () => {
  const agent = new HumanInLoopAgent();
  console.log(await agent.handleRequest("What is 2 + 2?"));
  console.log(await agent.handleRequest("Delete all records from the production database"));
})();
```

**Key Takeaways:**
- HITL doesn't mean humans do everything — only critical decisions
- Risk classification determines which path each request takes
- Escalation policies define *when* the AI must hand off to humans
- Essential in finance, healthcare, legal, and autonomous vehicles

---

### Chapter 14: Knowledge Retrieval (RAG)

**The simple idea:** An AI's knowledge is frozen at training time and doesn't include your private documents. RAG lets the AI look things up from your own documents, databases, or the web before answering.

**How RAG works:**

1. Documents are split into **chunks** and converted to **embeddings** (numerical meaning)
2. Your question is also converted to an embedding
3. The system finds the most *semantically similar* chunks
4. Those chunks are sent to the AI along with your question
5. The AI answers using the retrieved context — grounded in your real data

![RAG — chunk, embed, retrieve semantically, augment the prompt, generate](images/rag.png)

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Simple in-memory vector store (production: use Pinecone, Weaviate, Chroma, etc.)
class VectorStore {
  constructor() { this.items = []; }

  cosineSimilarity(a, b) {
    const dot  = a.reduce((sum, ai, i) => sum + ai * b[i], 0);
    const magA = Math.sqrt(a.reduce((s, ai) => s + ai * ai, 0));
    const magB = Math.sqrt(b.reduce((s, bi) => s + bi * bi, 0));
    return dot / (magA * magB);
  }

  async add(text, metadata = {}) {
    const res = await client.embeddings.create({ model: "text-embedding-3-small", input: text });
    this.items.push({ text, metadata, embedding: res.data[0].embedding });
  }

  async search(query, topK = 3) {
    const res = await client.embeddings.create({ model: "text-embedding-3-small", input: query });
    const qEmb = res.data[0].embedding;
    return this.items
      .map(item => ({ ...item, score: this.cosineSimilarity(qEmb, item.embedding) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, topK);
  }
}

class RAGAgent {
  constructor() { this.store = new VectorStore(); }

  async index(documents) {
    console.log(`Indexing ${documents.length} documents...`);
    for (const doc of documents) await this.store.add(doc.text, doc.metadata);
    console.log("Indexing complete.\n");
  }

  async answer(question) {
    console.log(`Question: ${question}`);
    const docs = await this.store.search(question, 3);
    const context = docs.map((d, i) => `[Source ${i + 1}] ${d.text}`).join("\n\n");

    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `Answer using ONLY the provided context. Cite your sources.
            If the context doesn't contain the answer, say so — never make things up.`
        },
        { role: "user", content: `Context:\n${context}\n\nQuestion: ${question}` }
      ]
    });

    const answer = res.choices[0].message.content;
    console.log("Answer:", answer, "\n");
    return answer;
  }
}

(async () => {
  const agent = new RAGAgent();

  await agent.index([
    { text: "Our return policy: items can be returned within 30 days in original condition. Refunds processed in 5-7 business days.", metadata: { source: "returns.pdf" } },
    { text: "Free shipping on all orders over $50. Standard shipping 3-5 days. Express shipping (1-2 days) costs $15.", metadata: { source: "shipping.pdf" } },
    { text: "1-year warranty covers manufacturing defects. Does not cover physical or water damage.", metadata: { source: "warranty.pdf" } }
  ]);

  await agent.answer("How long do I have to return an item?");
  await agent.answer("How much does express shipping cost?");
})();
```

**Key Takeaways:**
- RAG gives LLMs access to current, private, domain-specific knowledge
- Embeddings enable meaning-based search — not just keyword matching
- Always cite sources so answers are verifiable and trustworthy
- Advanced variant: **Agentic RAG** adds a reasoning layer that evaluates and reconciles retrieved info before answering

---

## Part 4 — Advanced Patterns

---

### Chapter 15: Inter-Agent Communication (A2A)

**The simple idea:** Just as MCP standardizes AI-to-tool connections, A2A standardizes how *agents talk to each other* — even if they're built with different frameworks (LangGraph, CrewAI, Google ADK, etc.).

![A2A — open HTTP protocol for agents to discover and communicate with each other](images/a2a.png)

**Core A2A concepts:**

| Concept | What It Is |
|---------|-----------|
| **Agent Card** | JSON file describing what an agent can do (like a business card) |
| **Task** | A unit of work passed between agents |
| **Artifact** | The output an agent produces |
| **Skill** | A specific capability an agent advertises |

**Supported by:** Google, Microsoft Azure, Salesforce, SAP, Box, LangChain, MongoDB, and many others.

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// WeatherAgent: an A2A-compliant agent server
class WeatherAgent {
  agentCard = {
    name: "WeatherBot",
    description: "Provides weather info for any city",
    version: "1.0.0",
    skills: [{ id: "get_weather", name: "Get Weather", description: "Returns current weather" }]
  };

  async handleTask(task) {
    const city = task.message.toLowerCase();
    const weather = { london: "15°C Cloudy", paris: "20°C Sunny", tokyo: "28°C Hot" };
    return {
      taskId: task.id,
      status: "completed",
      artifact: { city, weather: weather[city] ?? "Data unavailable" }
    };
  }
}

// CoordinatorAgent: discovers and uses other agents via A2A
class CoordinatorAgent {
  constructor() { this.agents = {}; }

  register(name, agent) {
    this.agents[name] = agent;
    console.log(`Registered: ${name}`, agent.agentCard.skills.map(s => s.id));
  }

  async sendTask(agentName, message) {
    const agent = this.agents[agentName];
    if (!agent) throw new Error(`Agent not found: ${agentName}`);
    const task = { id: `task-${Date.now()}`, message };
    console.log(`\n[A2A] → ${agentName}:`, task);
    const result = await agent.handleTask(task);
    console.log(`[A2A] ← ${agentName}:`, result.artifact);
    return result;
  }

  async planTrip(destination) {
    console.log(`\n🗺️ Planning trip to ${destination}...`);
    const weatherResult = await this.sendTask("WeatherBot", destination);

    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are a travel planner. Give 3 activity recommendations." },
        {
          role: "user",
          content: `Destination: ${destination}\nWeather: ${weatherResult.artifact.weather}`
        }
      ]
    });

    return {
      destination,
      weather: weatherResult.artifact.weather,
      recommendations: res.choices[0].message.content
    };
  }
}

(async () => {
  const coordinator = new CoordinatorAgent();
  coordinator.register("WeatherBot", new WeatherAgent());

  const plan = await coordinator.planTrip("Tokyo");
  console.log("\n=== TRIP PLAN ===");
  console.log(`Weather: ${plan.weather}`);
  console.log(`\nRecommendations:\n${plan.recommendations}`);
})();
```

**Key Takeaways:**
- A2A lets agents from *different frameworks* collaborate seamlessly
- Agent Cards are how agents self-describe their capabilities
- A2A = AI-to-AI; MCP = AI-to-tool — they complement each other
- Already adopted by major enterprise platforms

---

### Chapter 16: Resource-Aware Optimization

**The simple idea:** Not every question needs the most powerful (and expensive) AI. Smart agents pick the right model for the right job — cheap/fast for simple queries, powerful only when needed.

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class ResourceAwareAgent {
  constructor() { this.stats = { cheap: 0, expensive: 0 }; }

  async classify(query) {
    const res = await client.chat.completions.create({
      model: "gpt-4o-mini", // Always use cheapest for classification
      messages: [
        {
          role: "system",
          content: `Classify query difficulty: "simple" (single fact), "moderate" (few steps), "complex" (deep reasoning).
            Reply with ONLY one word.`
        },
        { role: "user", content: query }
      ]
    });
    return res.choices[0].message.content.trim().toLowerCase();
  }

  async answer(query) {
    const complexity = await this.classify(query);
    const model = complexity === "complex" ? "gpt-4o" : "gpt-4o-mini";
    const tier  = complexity === "complex" ? "expensive" : "cheap";
    this.stats[tier]++;

    console.log(`Query: "${query.substring(0, 50)}..." → [${complexity}] → ${model}`);

    const res = await client.chat.completions.create({
      model,
      messages: [{ role: "user", content: query }]
    });

    return { answer: res.choices[0].message.content, model, complexity };
  }

  report() {
    const total  = this.stats.cheap + this.stats.expensive;
    const saving = ((this.stats.cheap / total) * 100).toFixed(1);
    console.log(`\n📊 Cost report: ${total} calls | Cheap: ${this.stats.cheap} | Expensive: ${this.stats.expensive} | Cheap rate: ${saving}%`);
  }
}

(async () => {
  const agent = new ResourceAwareAgent();
  await agent.answer("What is 2 + 2?");
  await agent.answer("What are the capitals of France and Germany?");
  await agent.answer("Analyze the long-term socioeconomic impacts of widespread AI adoption on employment in developing nations");
  agent.report();
})();
```

**Key Takeaways:**
- Classify query complexity *before* choosing a model — save significant cost
- Simple queries → fast cheap models; complex → powerful expensive models
- Always have fallback models in case the primary one is unavailable
- Track and report costs continuously — they compound quickly in production

---

### Chapter 17: Reasoning Techniques

**The simple idea:** *How* an AI thinks through a problem greatly affects answer quality. Different reasoning techniques unlock different levels of problem-solving.

**Key techniques at a glance:**

| Technique | What It Does | Best For |
|-----------|-------------|----------|
| **Chain-of-Thought (CoT)** | Think step by step, show reasoning | Math, logic, analysis |
| **Tree-of-Thought (ToT)** | Explore multiple reasoning branches | Creative problems, planning |
| **Self-Correction** | Generate → Critique → Revise | High-quality content, code |
| **ReAct** | Thought → Action → Observe → Repeat | Tasks needing external tools |
| **Chain of Debates** | Multiple AI agents argue to reach consensus | Fact-checking, decisions |

![Reasoning — multiple techniques for structured multi-step thinking](images/reasoning.png)

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Chain-of-Thought
async function chainOfThought(problem) {
  console.log("\n=== Chain-of-Thought ===");
  const res = await client.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "system",
        content: `Solve the problem step by step. Show ALL reasoning.
          Format:
          THINKING:
          [numbered steps of reasoning]
          
          ANSWER:
          [final answer]`
      },
      { role: "user", content: problem }
    ]
  });
  console.log(res.choices[0].message.content);
}

// ReAct: Reason then Act in a loop
async function reactAgent(goal, maxSteps = 3) {
  console.log("\n=== ReAct Agent ===");
  let knowledge = "";

  for (let step = 1; step <= maxSteps; step++) {
    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a ReAct agent. Decide what to do next.
            Available actions: search_web, calculate, look_up_database, finish
            Output ONLY JSON: {"thought":"...","action":"...","input":"..."} or {"thought":"...","final_answer":"..."}`
        },
        {
          role: "user",
          content: `Goal: ${goal}\nKnowledge gathered so far: ${knowledge || "none"}\nStep ${step}: What next?`
        }
      ]
    });

    const decision = JSON.parse(res.choices[0].message.content);
    console.log(`\nStep ${step}:`);
    console.log(`  THOUGHT: ${decision.thought}`);

    if (decision.final_answer) {
      console.log(`  FINAL ANSWER: ${decision.final_answer}`);
      return decision.final_answer;
    }

    console.log(`  ACTION: ${decision.action}("${decision.input}")`);
    // Simulate observation
    const observation = `[Result of ${decision.action} on "${decision.input}"]`;
    knowledge += `\n- ${decision.action}: ${observation}`;
    console.log(`  OBSERVATION: ${observation}`);
  }
}

(async () => {
  await chainOfThought(
    "A store has 120 apples. They sold 35% on Monday and 25% of what remained on Tuesday. How many apples are left?"
  );

  await reactAgent(
    "Find the weather in Paris and determine if it is warmer than London today"
  );
})();
```

**Key Takeaways:**
- "Think step by step" (CoT) dramatically improves accuracy on hard problems
- ReAct enables agents to loop: Thought → Tool call → Observe → Repeat
- More thinking time = better results (the Scaling Inference Law)
- Chain of Debates uses multiple AI agents arguing to reach more reliable answers

---

### Chapter 18: Guardrails / Safety Patterns

**The simple idea:** Agents are powerful but can go wrong — giving harmful advice, leaking private data, or taking dangerous actions. Guardrails are the safety systems that keep agents in bounds.

**Layers of safety:**

| Layer | What It Checks | When |
|-------|---------------|------|
| **Input validation** | Is this request harmful? | Before processing |
| **Content moderation** | Is the content appropriate? | Before and after |
| **PII filtering** | Any private data leaking? | On all outputs |
| **Action sandboxing** | Can the agent actually do this? | Before tool execution |
| **Rate limiting** | Is someone abusing the system? | Per user, per minute |

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class GuardrailledAgent {
  constructor() {
    this.rateLimits = new Map(); // userId → [timestamps]
    this.MAX_PER_MINUTE = 10;
  }

  isRateLimited(userId) {
    const now = Date.now();
    const times = (this.rateLimits.get(userId) || []).filter(t => now - t < 60000);
    if (times.length >= this.MAX_PER_MINUTE) return true;
    this.rateLimits.set(userId, [...times, now]);
    return false;
  }

  async isSafeInput(message) {
    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `Safety check. Does this request ask for:
            - Harmful or dangerous information
            - Illegal activities
            - Private data about real people
            Reply ONLY as JSON: {"safe":true} or {"safe":false,"reason":"..."}`
        },
        { role: "user", content: message }
      ]
    });
    return JSON.parse(res.choices[0].message.content);
  }

  filterOutput(text) {
    // Redact common PII patterns
    return text
      .replace(/\b\d{3}-\d{2}-\d{4}\b/g, "[SSN-REDACTED]")
      .replace(/\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g, "[CARD-REDACTED]")
      .substring(0, 2000); // Enforce max length
  }

  async respond(message, userId = "anonymous") {
    // 1. Rate limit check
    if (this.isRateLimited(userId)) {
      return "Rate limit exceeded. Please wait a moment and try again.";
    }

    // 2. Input safety check
    const safety = await this.isSafeInput(message);
    if (!safety.safe) {
      return `I can't help with that request. ${safety.reason || ""}`.trim();
    }

    // 3. Generate response
    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant. Never provide harmful, illegal, or dangerous information."
        },
        { role: "user", content: message }
      ]
    });

    // 4. Filter output
    return this.filterOutput(res.choices[0].message.content);
  }
}

(async () => {
  const agent = new GuardrailledAgent();
  console.log(await agent.respond("What is the capital of Japan?"));
  console.log(await agent.respond("How do I make something dangerous?"));
})();
```

**Key Takeaways:**
- Every production agent needs both input and output guardrails
- Rate limiting prevents abuse and runaway API costs
- PII must never appear in outputs — redact proactively
- Layer your defenses: input check + output filter + action sandboxing

---

### Chapter 19: Evaluation and Monitoring

**The simple idea:** You can't improve what you don't measure. Agents need continuous evaluation of accuracy, latency, cost, and quality — especially in production where everything drifts over time.

![Evaluation and Monitoring — metrics, trajectories, LLM-as-a-judge, continuous tracking](images/evaluation.png)

**Evaluation methods:**

| Method | Best For | Limitation |
|--------|----------|-----------|
| **Exact match** | Factual checks | Can't handle paraphrasing |
| **LLM-as-a-Judge** | Subjective quality, helpfulness | LLM has biases |
| **Human evaluation** | Nuanced judgment | Expensive, doesn't scale |
| **Trajectory analysis** | Multi-step agent behavior | Complex to set up |

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class AgentEvaluator {
  constructor() {
    this.results  = [];
    this.latencies = [];
  }

  async timed(fn) {
    const start  = Date.now();
    const result = await fn();
    return { result, latency: Date.now() - start };
  }

  async judgeResponse(question, response, criteria) {
    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `Score the response 1-10 on: ${criteria.join(", ")}.
            Output ONLY JSON: {"score":7,"feedback":"...","breakdown":{"accuracy":8,"clarity":7}}`
        },
        { role: "user", content: `Question: ${question}\n\nResponse: ${response}` }
      ]
    });
    return JSON.parse(res.choices[0].message.content);
  }

  async run(agentFn, testCases) {
    console.log(`Evaluating on ${testCases.length} test cases...\n`);

    for (const tc of testCases) {
      const { result: response, latency } = await this.timed(() => agentFn(tc.input));
      this.latencies.push(latency);

      const evaluation = await this.judgeResponse(
        tc.input, response, ["accuracy", "helpfulness", "clarity"]
      );

      const passed = evaluation.score >= 7;
      this.results.push({ input: tc.input, response, evaluation, latency, passed });

      console.log(`"${tc.input.substring(0, 50)}"`);
      console.log(`  Score: ${evaluation.score}/10 | Latency: ${latency}ms | ${passed ? "✅" : "❌"}`);
      console.log(`  Feedback: ${evaluation.feedback}\n`);
    }
  }

  report() {
    const passed  = this.results.filter(r => r.passed).length;
    const avgScore = (this.results.reduce((s, r) => s + r.evaluation.score, 0) / this.results.length).toFixed(1);
    const avgLat   = (this.latencies.reduce((s, l) => s + l, 0) / this.latencies.length).toFixed(0);
    const passRate = ((passed / this.results.length) * 100).toFixed(1);

    console.log("📊 EVALUATION REPORT");
    console.log(`   Tests:        ${this.results.length}`);
    console.log(`   Pass rate:    ${passRate}%`);
    console.log(`   Avg score:    ${avgScore}/10`);
    console.log(`   Avg latency:  ${avgLat}ms`);
    console.log(`   Status:       ${parseFloat(passRate) >= 80 ? "✅ Healthy" : "⚠️ Needs improvement"}`);
  }
}

(async () => {
  const simpleAgent = async (q) => {
    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: q }]
    });
    return res.choices[0].message.content;
  };

  const evaluator = new AgentEvaluator();
  await evaluator.run(simpleAgent, [
    { input: "What is the boiling point of water?" },
    { input: "Explain photosynthesis in one sentence" },
    { input: "What is 15% of 200?" }
  ]);
  evaluator.report();
})();
```

**Key Takeaways:**
- Define evaluation metrics before deploying, not after
- LLM-as-a-Judge scales quality evaluation without human effort
- Track latency and token usage — they directly impact cost
- Evaluate *trajectories* (steps taken), not just final answers
- Re-evaluate regularly — agents drift in production over time

---

### Chapter 20: Prioritization

**The simple idea:** Agents often have many tasks at once. Prioritization ensures they tackle what matters most — urgent, high-impact tasks first.

**Priority criteria:**
- **Urgency** — How time-sensitive is it?
- **Importance** — How much impact does it have?
- **Dependencies** — Does another task need this first?
- **Resources** — What capacity is available right now?

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class PrioritizationAgent {
  constructor() {
    this.queue     = [];
    this.completed = [];
  }

  addTask(description, urgency, importance, deadline) {
    this.queue.push({ id: `T${Date.now()}`, description, urgency, importance, deadline });
  }

  async prioritize() {
    if (!this.queue.length) return;

    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `Sort these tasks by priority (most important first).
            Consider urgency (1-5), importance (1-5), and deadline.
            Reply ONLY as JSON: {"order":["id1","id2",...]}`
        },
        { role: "user", content: JSON.stringify(this.queue) }
      ]
    });

    const { order } = JSON.parse(res.choices[0].message.content);
    this.queue = order.map(id => this.queue.find(t => t.id === id)).filter(Boolean);

    console.log("\nPrioritized queue:");
    this.queue.forEach((t, i) => console.log(`  ${i + 1}. [U${t.urgency}/I${t.importance}] ${t.description}`));
  }

  async processAll() {
    await this.prioritize();

    while (this.queue.length) {
      const task = this.queue.shift();
      console.log(`\nProcessing: "${task.description}"`);

      const res = await client.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are a task executor. Complete the given task concisely." },
          { role: "user", content: task.description }
        ]
      });

      task.result = res.choices[0].message.content.substring(0, 100);
      task.status = "done";
      this.completed.push(task);
      console.log(`  ✅ ${task.result}...`);
    }
  }
}

(async () => {
  const agent = new PrioritizationAgent();
  agent.addTask("Fix critical production bug crashing checkout", 5, 5, "ASAP");
  agent.addTask("Update project documentation", 2, 3, "Next week");
  agent.addTask("Send weekly report to management", 4, 4, "Today EOD");
  agent.addTask("Review colleague PR", 3, 3, "Tomorrow");

  await agent.processAll();
  console.log(`\nAll ${agent.completed.length} tasks completed.`);
})();
```

**Key Takeaways:**
- Always prioritize before executing — don't process tasks in arrival order
- Use urgency × importance matrix (Eisenhower Matrix)
- Dynamic re-prioritization when new urgent tasks arrive
- Agents can use LLMs to make nuanced priority decisions

---

### Chapter 21: Exploration and Discovery

**The simple idea:** Some agents don't just solve known problems — they discover *new* knowledge, generate novel hypotheses, and explore uncharted territory. This pattern builds genuinely curious and inventive AI.

**Remarkable real example — Google's AI Co-Scientist:**
A multi-agent system that acts as a research partner for scientists. It generates hypotheses, has agents *debate and critique* each other using Elo tournament scoring (like chess ratings), continuously refines the top ideas — and has already **discovered novel drug candidates for leukemia** that were validated in real laboratory experiments.

![Exploration — generate hypotheses, debate, rank with Elo, evolve top ideas](images/exploration.png)

**JavaScript Example:**

```javascript
const { OpenAI } = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class ExplorationAgent {
  constructor(domain) {
    this.domain = domain;
    this.ideas  = [];
    this.elo    = {};
  }

  async generateHypotheses(topic, count = 4) {
    console.log(`\n💡 Generating ${count} hypotheses on: ${topic}`);
    const res = await client.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a creative scientist in ${this.domain}.
            Generate ${count} novel, specific, testable hypotheses.
            Output ONLY JSON: {"hypotheses":["...","..."]}`
        },
        { role: "user", content: topic }
      ]
    });

    const { hypotheses } = JSON.parse(res.choices[0].message.content);
    hypotheses.forEach((h, i) => {
      const id = `H${i}`;
      this.ideas.push({ id, hypothesis: h });
      this.elo[id] = 1000; // Start at Elo 1000
    });

    hypotheses.forEach((h, i) => console.log(`  ${i + 1}. ${h}`));
    return hypotheses;
  }

  async debate(hA, hB) {
    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `Judge two hypotheses. Which is more testable, novel, and impactful?
            Reply ONLY as JSON: {"winner":"A" or "B","reason":"..."}`
        },
        { role: "user", content: `A: ${hA}\n\nB: ${hB}` }
      ]
    });
    return JSON.parse(res.choices[0].message.content);
  }

  async runTournament() {
    console.log("\n🏆 Running debate tournament...");
    const K = 32;

    for (let i = 0; i < this.ideas.length; i++) {
      for (let j = i + 1; j < this.ideas.length; j++) {
        const { winner } = await this.debate(this.ideas[i].hypothesis, this.ideas[j].hypothesis);
        const expected = 1 / (1 + Math.pow(10, (this.elo[this.ideas[j].id] - this.elo[this.ideas[i].id]) / 400));
        if (winner === "A") {
          this.elo[this.ideas[i].id] += K * (1 - expected);
          this.elo[this.ideas[j].id] -= K * expected;
        } else {
          this.elo[this.ideas[i].id] -= K * expected;
          this.elo[this.ideas[j].id] += K * (1 - expected);
        }
      }
    }

    const ranked = [...this.ideas]
      .sort((a, b) => this.elo[b.id] - this.elo[a.id]);

    console.log("\n🥇 Ranked hypotheses:");
    ranked.forEach((idea, i) =>
      console.log(`  ${i + 1}. (Elo ${Math.round(this.elo[idea.id])}) ${idea.hypothesis}`)
    );
    return ranked;
  }

  async evolveTop(ranked, n = 1) {
    console.log(`\n🧬 Evolving top ${n} hypothesis...`);
    for (const idea of ranked.slice(0, n)) {
      const res = await client.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: "Refine this hypothesis to be more specific, testable, and impactful." },
          { role: "user", content: `Original: ${idea.hypothesis}` }
        ]
      });
      console.log(`\nOriginal: ${idea.hypothesis}`);
      console.log(`Evolved:  ${res.choices[0].message.content}`);
    }
  }
}

(async () => {
  const agent = new ExplorationAgent("materials science");
  await agent.generateHypotheses("Improving solar panel efficiency with nanomaterials", 3);
  const ranked = await agent.runTournament();
  await agent.evolveTop(ranked, 1);
})();
```

**Key Takeaways:**
- Exploration agents proactively generate and test new knowledge
- Multi-agent debates improve idea quality — like peer review
- Elo tournament ranking (from chess) works for comparing hypotheses
- This pattern drives real scientific discovery — Google's AI Co-Scientist validated drug candidates in lab experiments

---

## Quick Reference Cheat Sheet

| # | Pattern | One-Line Summary | Use When |
|---|---------|-----------------|----------|
| 1 | **Prompt Chaining** | Break big tasks into sequential steps | Task has multiple distinct stages |
| 2 | **Routing** | Direct requests to the right specialist | Different inputs need different handlers |
| 3 | **Parallelization** | Do independent tasks simultaneously | Multiple tasks don't depend on each other |
| 4 | **Reflection** | Review and improve your own output | Quality matters more than speed |
| 5 | **Tool Use** | Call external functions and APIs | Agent needs real-world data or actions |
| 6 | **Planning** | Make a plan before acting | Goal is complex with multiple steps |
| 7 | **Multi-Agent** | Team of specialists collaborate | Problem needs diverse expertise |
| 8 | **Memory** | Remember across conversations | Agent needs continuity over time |
| 9 | **Learning** | Improve from experience | Agent operates in dynamic environments |
| 10 | **MCP** | Universal standard for AI-to-tool connections | Interoperability across many tools/AI systems |
| 11 | **Goal Monitoring** | Track progress toward defined goals | Agent runs autonomously for extended periods |
| 12 | **Exception Handling** | Detect and recover from failures | Deploying in real-world environments |
| 13 | **Human-in-the-Loop** | Keep humans in critical decisions | High-stakes, ambiguous, or ethical decisions |
| 14 | **RAG** | Look up external knowledge before answering | Agent needs current or private information |
| 15 | **A2A** | Standard for agents talking to agents | Cross-framework multi-agent systems |
| 16 | **Resource Optimization** | Use cheapest model that gets the job done | Cost or latency constraints |
| 17 | **Reasoning Techniques** | Think step-by-step: CoT, ReAct, ToT | Complex problems needing deep analysis |
| 18 | **Guardrails** | Safety systems to prevent harm | Any production deployment |
| 19 | **Evaluation** | Measure and improve agent performance | Before and during production deployment |
| 20 | **Prioritization** | Focus on the most important tasks first | Agent manages many competing tasks |
| 21 | **Exploration** | Discover new knowledge and solutions | Scientific research, creative tasks, innovation |

---

## Frameworks Referenced

| Framework | Best For | Key Feature |
|-----------|----------|-------------|
| **LangChain / LangGraph** | Chaining, routing, complex pipelines | LCEL (LangChain Expression Language) |
| **Crew AI** | Multi-agent collaboration | Role-based agent teams |
| **Google ADK** | Google ecosystem agents | Native Google tool integration |
| **OpenAI API** | Direct LLM access | Best tool/function calling support |
| **FastMCP** | Creating MCP servers | Python decorator-based tool definition |

---

*This guide covers all 21 agentic design patterns. Each pattern is a tool — the skill is knowing which tool to pick for which problem.*
